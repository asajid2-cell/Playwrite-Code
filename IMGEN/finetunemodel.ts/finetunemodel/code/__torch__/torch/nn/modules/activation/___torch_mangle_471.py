class SiLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_471.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu(argument_1)
  def forward1(self: __torch__.torch.nn.modules.activation.___torch_mangle_471.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu(argument_1)
  def forward2(self: __torch__.torch.nn.modules.activation.___torch_mangle_471.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu(argument_1)
