class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.diffusers.models.transformers.transformer_2d.___torch_mangle_117.Transformer2DModel
  __annotations__["1"] = __torch__.diffusers.models.transformers.transformer_2d.___torch_mangle_146.Transformer2DModel
