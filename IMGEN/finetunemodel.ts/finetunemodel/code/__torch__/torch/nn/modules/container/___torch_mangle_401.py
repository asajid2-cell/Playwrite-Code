class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  __annotations__["0"] = __torch__.diffusers.models.resnet.___torch_mangle_382.ResnetBlock2D
  __annotations__["1"] = __torch__.diffusers.models.resnet.___torch_mangle_391.ResnetBlock2D
  __annotations__["2"] = __torch__.diffusers.models.resnet.___torch_mangle_400.ResnetBlock2D
